﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Collections;

namespace Assignment_1
{
    class Student
    {
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string smailid { get; set; }
        public string branch { get; set; }
        public double per { get; set; }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
                List<Student> Slist = new List<Student>()
                {
                 new Student(){firstname="Suraj",lastname ="pamu",smailid ="surajpamu570@gmail.com",branch="CSE",per= 85.6},
                 new Student(){firstname="Arjun",lastname ="singh",smailid ="arjun15@gmail.com",branch="CSE",per= 89.3},
                 new Student(){firstname="sajid",lastname ="shake",smailid ="sajidsk70@gmail.com",branch="MEC",per= 78.5},
                 new Student(){firstname="veer",lastname ="sai",smailid ="veersai486@gmail.com",branch="ECE",per= 70.6},
                 new Student(){firstname="karan",lastname ="kumar",smailid ="karan753@gmail.com",branch="ECE",per= 84.2},
                 new Student(){firstname="Ravi",lastname ="mohan",smailid ="ravi753@gmail.com",branch="CIVIL",per= 75.2},
                 new Student(){firstname="Raj",lastname ="kumar",smailid ="raj500@gmail.com",branch="EEE",per= 84.2}
                };

            //Select
            Console.WriteLine("----------Select----------");
            var query = from i in Slist select i.firstname; //LINQ
            foreach(var i in query)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("--------------------");

            var query1 = Slist.Select(i => i.firstname); //lamda exp

            foreach (var i in query1)
            {
                Console.WriteLine(i);
            }

            //where
            Console.WriteLine("----------Where----------");
            var top2student = from i in Slist
                              where i.per > 85
                              select i;
            Console.WriteLine("top students are:");
            foreach (Student stu in top2student)
            {
                Console.WriteLine(stu.firstname);
            }
            Console.WriteLine("--------------------");

            IEnumerable<Student> topstudents = Slist.Where(s => s.per > 85);
            Console.WriteLine("top students are:");
            foreach (Student stu in topstudents)
            { 
                Console.WriteLine(stu.firstname);
            }

            // skip
            Console.WriteLine("---------skip-----------");
            IEnumerable<Student> query2 = (from i in Slist select i).Skip(2);
            foreach (var i in query2)
            {
                Console.WriteLine(i.firstname);
            }
            Console.WriteLine("--------------------");


            var query3 = Slist.Skip(2);
            foreach (var i in query3)
            {
                Console.WriteLine(i.firstname);
            }

            //skipwhile
            Console.WriteLine("----------Skipwhile----------");
            IEnumerable<Student> query4 = (from i in Slist select i).SkipWhile(i => i.branch=="CSE");
            foreach (var i in query4)
            {
                Console.WriteLine($"studentname:{i.firstname} branch:{i.branch}");
            }

            //take
            Console.WriteLine("---------take-----------");
            IEnumerable<Student> query6 = (from i in Slist select i).Take(2);
            foreach (var i in query6)
            {
                Console.WriteLine(i.firstname);
            }
            Console.WriteLine("--------------------");


            var query7 = Slist.Take(3);
            foreach (var i in query7)
            {
                Console.WriteLine(i.firstname);
            }

            //takewhile
            Console.WriteLine("----------takewhile----------");
            IEnumerable<Student> query8 = (from i in Slist select i).TakeWhile(i =>i.branch=="CSE");
            foreach(var i in query8)
            {
                Console.WriteLine($"studentname:{i.firstname} branch:{i.branch}");
            }
            Console.WriteLine("--------------------");

            var query9 = Slist.TakeWhile(i => i.per > 75);
            foreach (var i in query9)
            {
                Console.WriteLine(i.firstname);
            }
            // OrderBy query
            Console.WriteLine("-----------OrderBy query---------------");
            Console.WriteLine("1.Ascn order");
            var query10 = Slist.OrderBy(i => i.per);
            foreach (var i in query10)
            {
                Console.WriteLine($"{i.firstname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("--------------------");

            Console.WriteLine("2.Decn Order");
            var query11 = Slist.OrderByDescending(i => i.per);
            foreach (var i in query11)
            {
                Console.WriteLine($"{i.firstname},{i.smailid},{i.branch},{i.per}");
            }

            //GroupBy
            Console.WriteLine("----------Groupby----------");
            var iGroup1 = Slist.GroupBy(i => i.branch);
            var iGroup2 = Slist.GroupBy(i => i.per);

            foreach (var value in iGroup1)
            {
                Console.WriteLine("----------");
                Console.WriteLine(value.Key);
                Console.WriteLine("----------");
                foreach (var k in value)
                {
                    Console.WriteLine(k.firstname);
                }
            }
            Console.WriteLine("**************************");

            foreach (var valu in iGroup2)
            {
                Console.WriteLine("----------");
                Console.WriteLine(valu.Key);

                foreach (var k in valu)
                {
                    Console.WriteLine(k.firstname);
                }
            }

            // SelectMany
            Console.WriteLine("----------select many----------");
            List<List<int>> li = new List<List<int>>();
            List<int> liin=new List<int> { 1,2,3,4};
            li.Add(liin);
            var query13 = li.SelectMany(i => i);
            foreach (var i in query13)
            {
                Console.WriteLine(i);
            }

            //Aggregate Functions
            Console.WriteLine("----------Aggregate Functions----------");
            Console.WriteLine("Sum");
            var query14 = Slist.Sum(i => i.per);
            Console.WriteLine($"sum of all percentages:{query14}");
            Console.WriteLine("******");

            Console.WriteLine("Max");
            var query15 = Slist.Max(i => i.per);
            Console.WriteLine($"Max percentage:{query15}");
            Console.WriteLine("******");

            Console.WriteLine("Min");
            var query16 = Slist.Min(i => i.per);
            Console.WriteLine($"Min percentage:{query16}");
            Console.WriteLine("******");

            Console.WriteLine("Average");
            var query17 = Slist.Average(i => i.per);
            Console.WriteLine($"Average of all percentages:{query17}");
            Console.WriteLine("******");

            Console.WriteLine("Count");
            var query18 = Slist.Count(i => i.per>75);
            Console.WriteLine($"count of all percentages > 75%:{query18}");
            Console.WriteLine("******");

            Console.WriteLine("Distinct");
            List<int> li1 = new List<int>() { 1, 1, 2, 2, 3, 4, 5, 6, 6, 7};
            var query19 = li1.Distinct();
            foreach (var i in query19)
            {
                Console.WriteLine($"{i}");
            }

            //Let
            Console.WriteLine("-----------Let---------------");
            var query20 = from i in li1 let res = i + 10 select res;
            foreach (var i in query20)
            {
                Console.WriteLine($"{i}");
            }

            //into
            Console.WriteLine("---------into-----------");
            var query21 = from i in Slist
                        where i.branch == "CSE"
                        select i into res
                        where res.firstname.StartsWith("S")
                        select res;
            
            foreach (var i in query21)
            {
                Console.WriteLine($"name:{i.firstname},email id: {i.smailid},branch: {i.branch}");
            }
            Console.WriteLine("----------");

            object[] obj = new object[] { 1, "String", 2, "Double" };
            Console.WriteLine("---------------Oftype Query-------------");
            Console.WriteLine("All the integer type values in the obj");
            var query22 = obj.OfType<int>();
            foreach (var i in query22)
            {
                Console.WriteLine($"{i}");
            }

            Console.WriteLine("------------First Query--------------");
            var query23 = Slist.Where(i => i.per < 85).First();
            Console.WriteLine($"{query23.firstname},{query23.lastname},{query23.smailid},{query23.branch},{query23.per}");
            Console.WriteLine("------------FirstOrDefault Query--------------");
            var query24 = Slist.Where(i => i.per > 100).FirstOrDefault();
            Console.WriteLine($"Value = {query24}");
            Console.WriteLine("------------Last Query--------------");
            var query25 = Slist.Where(i => i.per < 85).Last();
            Console.WriteLine($"{query25.firstname},{query25.lastname},{query25.smailid},{query25.branch},{query25.per}");
            Console.WriteLine("-----------LastOrDefault Query--------------");
            var query26 = Slist.Where(i => i.per > 100).LastOrDefault();
            Console.WriteLine($"Value = {query26}");
            Console.WriteLine("------------Single Query--------------");
            var query27 = Slist.Where(i => i.per > 87).Single();
            Console.WriteLine($"{query27.firstname},{query27.lastname},{query27.smailid},{query27.branch},{query27.per}");
            Console.WriteLine("------------SingleOrDefault Query--------------");
            var query28 = Slist.Where(i => i.per > 100).SingleOrDefault();
            Console.WriteLine($"Value = {query28}");



            Console.WriteLine($"-----------Deffrered Execution-----------------");
            var query29 = from i in Slist select i;
            Slist.Add(new Student() { firstname = "Manu", lastname = "Jain", smailid = "manujani456@gmail.com", branch = "ECE", per = 93 });
            foreach (var i in query29)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }


            Console.WriteLine($"-----------Immediate Execution-----------------");
            var query30 = (from i in Slist where i.per < 85 select i).Count();
            Slist.Add(new Student() { firstname = "Venkat", lastname = "kumar", smailid = "venkat753.com", branch = "MEC", per = 87 });
            Console.WriteLine($"Count of all values pre<95 : {query30}");


            Console.WriteLine("------------StartsWith-------------------");
            var query31 = Slist.Where(i => i.firstname.StartsWith('S'));
            foreach (var i in query31)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------EndsWith-------------------");
            var query32 = Slist.Where(i => i.firstname.EndsWith('d'));
            foreach (var i in query32)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n------------Contains-------------------");
            var query33 = Slist.Where(i => i.firstname.Contains('s'));
            foreach (var i in query33)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-------------IEnumarable---------------");
            IEnumerable<Student> query34 = from i in Slist select i;
            query34 = query34.Take(2);
            foreach (var i in query34)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }
            Console.WriteLine("\n-------------IQuerable-----------------");
            IQueryable<Student> query35 = Slist.AsQueryable();
            query35 = query35.Take(2);
            foreach (var i in query35)
            {
                Console.WriteLine($"{i.firstname},{i.lastname},{i.smailid},{i.branch},{i.per}");
            }

            Console.WriteLine("------------Q2---------------");
            int[] arr1 = new int[] { 10, 20, 30, 40, 50};
            int[] arr2 = new int[] { 10, 20, 60, 80};

            var query36 = arr1.Except(arr2);
            Console.WriteLine("------------Expect-----------");
            foreach (var i in query36)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-------------Union------------");
            var query37 = arr1.Union(arr2);
            foreach (var i in query37)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("---------------Intersect----------");
            var query38 = arr1.Intersect(arr2);
            foreach (var i in query38)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("---------------Concat----------");
            var query39 = arr1.Concat(arr2);
            foreach (var i in query39)
            {
                Console.WriteLine($"{i}");
            }
            Console.WriteLine("\n-------------Aggregate Functions---------------");
            var query40 = arr1.Sum(i => i);
            Console.WriteLine($"\n1.Sum of all elements in arr1 = {query40}");
            var query41 = arr1.Max(i => i);
            Console.WriteLine($"\n2.Max of all elements in arr1 = {query41}");
            var query42 = arr1.Min(i => i);
            Console.WriteLine($"\n3.Min of all elements in arr1 = {query42}");
            var query43 = arr1.Average(i => i);
            Console.WriteLine($"\n4.Average of all elements in arr1 = {query43}");
            Console.WriteLine("\n5.Count of all elements in arr1<30");
            var query44 = arr1.Count(i => i < 30);
            Console.WriteLine($"Count = {query44}");
            Console.WriteLine("\n6.Distinct");
            Console.WriteLine("All the distinct items of the arr1 array");
            var query45 = arr1.Distinct();
            foreach (var i in query45)
            {
                Console.WriteLine($"{i}");
            }
        }
    }
}
